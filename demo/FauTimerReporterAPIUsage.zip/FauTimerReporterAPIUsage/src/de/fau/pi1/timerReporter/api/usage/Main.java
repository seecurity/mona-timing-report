package de.fau.pi1.timerReporter.api.usage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import de.fau.pi1.timerReporter.dataset.Dataset;
import de.fau.pi1.timerReporter.evaluation.StatisticEvaluation;
import de.fau.pi1.timerReporter.plots.PlotPool;
import de.fau.pi1.timerReporter.reader.ReaderCsv;
import de.fau.pi1.timerReporter.tools.Conf;
import de.fau.pi1.timerReporter.tools.FileId;
import de.fau.pi1.timerReporter.tools.Folder;
import de.fau.pi1.timerReporter.writer.WriteHTML;
import de.fau.pi1.timerReporter.writer.WritePDF;



public class Main {

	/**
	 * This main class should describe how the fau-timer reporter works as library.
	 * 
	 * 
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args){
		
		Conf.getInstance();
		ArrayList<String> inputFiles = new ArrayList<String>();
		inputFiles.add("..\\FauTimerReporter\\demo\\example1\\input_local.csv");
		inputFiles.add("..\\FauTimerReporter\\demo\\example1\\input_remote.csv");
		inputFiles.add("..\\FauTimerReporter\\demo\\example2\\input_remote.csv");
		inputFiles.add("..\\FauTimerReporter\\demo\\example2\\input_local.csv");
		inputFiles.add("..\\FauTimerReporter\\demo\\example3\\output.csv");

		for (String inputFile : inputFiles) {

			Conf.put("inputFile", inputFile);

			// create new data set with secrets and times
			ReaderCsv reader = new ReaderCsv();
			Dataset dataset = new Dataset(reader);
			dataset.setName("New Measurement");
			String report = de.fau.pi1.timerReporter.main.Main.getReport();

			// create plot pool to multi threaded the plots
			PlotPool plotPool = new PlotPool(report, dataset);

			// plot the data set with the lower bound of 0.0 and the upper bound of 1.0
			plotPool.plot("Unfiltered Measurements", 0.0, 1.0);

			// plot the data set with the user input lower bound and upper bound
			plotPool.plot("Filtered Measurments: User Input", new Double(0.1), new Double(0.15));

			// build the evaluation phase
			StatisticEvaluation statisticEvaluation = new StatisticEvaluation(dataset, plotPool);
			
			/*
			 * this part shows how an optimal box is setted by a user
			 * 
			double[] userInputOptimalBox = new double[2];
			userInputOptimalBox[0] = new Double(0.10);
			userInputOptimalBox[1] = new Double(0.20);
			statisticEvaluation.setOptimalBox(userInputOptimalBox);
			*/
			
			// start the evaluation
			statisticEvaluation.calibrationPhase();
			
			// print the box test results into a csv file
			statisticEvaluation.printBoxTestResults(new File(report + Folder.getFileSep() + FileId.getId() +  "-" + "BoxTestResult.csv"));

			/*
			 * this part shows the getter of the evaluation results
			 * 
			for (BoxTestResults result : statisticEvaluation.getBoxTestResults()) {
				System.out.println(result.getInputFile() + " [" + result.getSecretA().getName() + "<" + result.getSecretB().getName() + "]: " + result.getOptimalBox()[0] + "-" + result.getOptimalBox()[1]);

				// iterate above all tested smallest sizes
				for(int i = 0; i < result.getSmallestSize().size(); ++i) {
					System.out.println("Minimum amouont of measurements: " + result.getSmallestSize().get(i) + "\nConfidence Interval: " + result.getConfidenceInterval().get(i));
					System.out.println("Subset A overlaps: " + Folder.convertArrayListToString(result.getSubsetOverlapA().get(i)));
					System.out.println("Subset B overlaps: " + Folder.convertArrayListToString(result.getSubsetOverlapB().get(i)));
					System.out.println("Subset A and B significant different: " + Folder.convertArrayListToString(result.getSignificantDifferent().get(i)));

				}
			}
 			*/
			
			// store the time lines
			ArrayList<String> timelineNames = statisticEvaluation.storeTimelines(report + Folder.getFileSep() + "images" + Folder.getFileSep());

			// close the thread pool
			plotPool.close();

			// write results in html and pdf
			new WriteHTML(dataset, report, plotPool).write();

			try {
				new WritePDF(dataset, report, plotPool, timelineNames).write();
			} catch (Exception e) {
				System.out.println("Error while writing the pdf.");
				System.exit(1);
			}

			// delete the folder tmp
			Folder.deleteTmp();
		}
	}
}